module.exports = {
    API_KEY: '39c0529c5af0b4c43b1ebee1ef9fbe6c', // İleti Merkezi'nden aldığınız API anahtarınız
    API_HASH: 'de0b8f7b837e699305f9bbd600de533917f90850f17329236047238b9989995b', // İleti Merkezi'nden aldığınız hash değeriniz
    SMS_SENDER: 'YOREM DONER' // Kullanmak istediğiniz başlık
};