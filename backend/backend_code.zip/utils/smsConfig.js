module.exports = {
    API_KEY: '77679f10ed4f4dbd78edaadcb04e6aff', // İleti Merkezi'nden aldığınız API anahtarınız
    API_HASH: '78b4fb02eb78570721024fe37e00d3a12ba7d0be945d7e4d40cf62fece685489', // İleti Merkezi'nden aldığınız hash değeriniz
    SMS_SENDER: 'BILGI' // Kullanmak istediğiniz başlık
};